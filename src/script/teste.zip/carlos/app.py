from datetime import datetime
import pytz

from flask import Flask, request, json
import requests
import logging
import time

from carlos.utils.users_utils import UsersUtils
from carlos.utils.utils import measure_time

app = Flask(__name__)

logger = logging.getLogger(__name__)
usersUltils = UsersUtils(logger)


@app.post('/users')
def postUsers():
    body = {}
    status = 200
    try:
        uploaded_file = request.files.get('file')
        if not uploaded_file:
            raise Exception("Nenhum arquivo enviado")

        file_content = uploaded_file.read().decode("utf-8")
        req = json.loads(file_content)

        usersUltils.load(req)
        body['user_count'] = usersUltils.countusers()
        body['message'] = "Arquivo recebido com sucesso"
    except Exception as e:
        logger.error("Erro manipular Json", exc_info=e)
        body['message'] = "erro manipular json usuários"
        status = 400
    finally:
        return body, status

@app.get('/superusers')
def getSuperUsers():
    inicio = time.time()
    body = {
        'timestamp': gettimestampnow()
    }
    status = 200
    try:
        body['data'] = usersUltils.getsuperusers()
    except Exception as e:
        logger.error("Erro manipular Json", exc_info=e)
        body['message'] = "erro manipular json"
        status = 500
    finally:
        fim = time.time()
        body['execution_time_ms'] = int((fim - inicio) * 1000)

        return body, status

@app.get('/top-countries')
def getTopCountries():
    inicio = time.time()
    body = {
        'timestamp': gettimestampnow()
    }
    status = 200
    try:
        body['countries'] = usersUltils.gettopcountries(5)
    except Exception as e:
        logger.error("Erro manipular Json", exc_info=e)
        body['message'] = "erro manipular json usuários"
        status = 500
    finally:
        fim = time.time()
        body['execution_time_ms'] = int((fim - inicio) * 1000)

        return body, status

@app.get('/team-insights')
def getTeamInsights():
    inicio = time.time()
    body = {
        'timestamp': gettimestampnow()
    }
    status = 200
    try:
        body['teams'] = usersUltils.getteaminsights()
    except Exception as e:
        logger.error("Erro manipular Json", exc_info=e)
        body['message'] = "erro manipular json usuários"
        status = 500
    finally:
        fim = time.time()
        body['execution_time_ms'] = int((fim - inicio) * 1000)
        return body, status

@app.get('/active-users-per-day')
def getActiveUsersPerDay():
    inicio = time.time()
    body = {
        'timestamp': gettimestampnow()
    }
    status = 200
    try:
        min_logins = request.args.get("min")
        body['logins'] = usersUltils.getloginsperday(min_logins)
    except Exception as e:
        logger.error("Erro manipular Json", exc_info=e)
        body['message'] = "erro manipular json usuários"
        status = 500
    finally:
        fim = time.time()
        body['execution_time_ms'] = int((fim - inicio) * 1000)
        return body, status

@app.get('/evaluation')
def evaluation():
    ENDPOINTS_TO_TEST = [
        {"name": "/superusuarios", "url": "http://localhost:5000/superusers"},
        {"name": "/ranking-paises", "url": "http://localhost:5000//top-countries"},
        {"name": "/analise-equipes", "url": "http://localhost:5000/team-insights"},
        {"name": "/usuarios-ativos-por-dia", "url": "http://localhost:5000/active-users-per-day"},
        #{"name": "/evaluation", "url": "http://localhost:5000/evaluation"},
    ]

    tested_endpoints = {}
    for endpoint in ENDPOINTS_TO_TEST:
        result = {}

        try:
            start_time = time.time()
            response = requests.get(endpoint['url'])
            end_time = time.time()

            result["status"] = str(response.status_code)
            result["time_ms"] = int((end_time - start_time) * 1000)

            # Verifica se é JSON válido
            try:
                response.json()
                result["valid_response"] = True
            except ValueError:
                result["valid_response"] = False

        except Exception as e:
            result["status"] = "ERROR"
            result["time_ms"] = -1
            result["valid_response"] = False

        tested_endpoints[endpoint['name']] = result

    # Montar resposta final
    resposta = {
        "timestamp": gettimestampnow(),
        "tested_endpoints": tested_endpoints
    }
    return resposta, 200


def gettimestampnow():
    brasilia_tz = pytz.timezone("America/Sao_Paulo")
    return datetime.now(brasilia_tz).strftime("%Y-%m-%dT%H:%M:%SZ")

if __name__ == '__main__':
    app.run(debug=True)
import pandas as pd

class UsersUtils:

    def __init__(self, logger):
        self.logger = logger
        self._user_df = pd.DataFrame()

    def load(self, users):
        self._users_json = users
        self._user_df = pd.DataFrame(users)


    def countusers(self):
        return len(self._user_df)

    def getsuperusers(self):
        filters = {
            'score_min': 900,
            'ativo': True
        }
        return self._dftojson(
            self._getuserswithfilters(filters)
        )

    def gettopcountries(self, total_top):
        filters = {
            'score_min': 900,
            'ativo': True
        }

        grouped = self._getuserswithfilters(filters).groupby("pais").size().reset_index(name="total")

        grouped = grouped.sort_values(by="total", ascending=False)
        top5 = grouped.head(total_top)

        countries = []
        for _, row in top5.iterrows():
            countries.append({
                "country": row["pais"],
                "total": row["total"]
            })

        return countries

    def getteaminsights(self):
        df = self._user_df.copy()

        # Expandir equipe
        equipe_df = pd.json_normalize(df['equipe'])

        # Renomear para evitar conflito de nomes
        equipe_df = equipe_df.rename(columns={
            "nome": "equipe_nome",
            "lider": "equipe_lider",
            "projetos": "equipe_projetos"
        })

        # Juntar
        df = df.join(equipe_df).drop(columns=['equipe'])

        # Explodir projetos
        df_explodido = df.explode('equipe_projetos')

        # Normalizar projetos
        projetos_df = pd.json_normalize(df_explodido['equipe_projetos'])
        df_explodido = df_explodido.drop(columns=['equipe_projetos']).reset_index(drop=True)
        df_explodido = pd.concat([df_explodido, projetos_df], axis=1)

        # Total de membros por equipe
        membros = df.groupby('equipe_nome')['equipe_nome'].count().rename("total_members")

        # Total de líderes por equipe
        lideres = df[df['equipe_lider'] == True].groupby('equipe_nome')['equipe_lider'].count().rename("leaders")

        # Total de projetos concluídos
        projetos_concluidos = df_explodido[df_explodido['concluido'] == True].groupby('equipe_nome')['concluido'].count().rename("completed_projects")

        # Percentual de ativos por equipe
        ativos = df[df['ativo'] == True].groupby('equipe_nome')['ativo'].count()
        total = df.groupby('equipe_nome')['ativo'].count()
        percentual_ativos = ((ativos / total) * 100).round(1).rename("active_percentage")

        # Unir todos
        resultado = pd.concat([membros, lideres, projetos_concluidos, percentual_ativos], axis=1).fillna(0)
        resultado['leaders'] = resultado['leaders'].astype(int)
        resultado['completed_projects'] = resultado['completed_projects'].astype(int)

        teams = []
        for _, row in resultado.reset_index().iterrows():
            teams.append({
                "team": row["equipe_nome"],
                "total_members": int(row["total_members"]),
                "leaders": int(row["leaders"]),
                "completed_projects": int(row["completed_projects"]),
                "active_percentage": row["active_percentage"]
            })

        return teams

    def getloginsperday(self, min_logins=None):
        df = self._user_df.copy()

        # Explodir os logs
        df_explodido = df.explode('logs')

        # Expandir os dados do log
        logs_df = pd.json_normalize(df_explodido['logs'])
        df_explodido = df_explodido.drop(columns=['logs']).reset_index(drop=True)
        df_explodido = pd.concat([df_explodido, logs_df], axis=1)

        # Filtrar apenas logins
        logins_df = df_explodido[df_explodido['acao'] == 'login']

        # Contar logins por data
        total_logins = logins_df.groupby('data').size().reset_index(name='total')

        # Filtrar mínimo, se fornecido
        if min_logins is not None:
            total_logins = total_logins[total_logins['total'] >= int(min_logins)]

        # Montar a lista no formato desejado
        logins = []
        for _, row in total_logins.iterrows():
            logins.append({
                "date": row['data'],
                "total": int(row['total'])
            })

        return logins
    def _getuserswithfilters(self, filters: dict):
        """
        Filtra os usuários com base nos critérios informados.

        Parâmetros:
            filters (dict): Dicionário com os critérios de filtragem. Chaves suportadas:
                - score_max (int): Retorna usuários com score menor ou igual a este valor.
                - score_min (int): Retorna usuários com score maior ou igual a este valor.
                - Qualquer outro nome de coluna (por exemplo, 'pais', 'ativo', 'idade'): Retorna usuários que correspondem exatamente ao valor informado.

        Retorna:
            list: Lista de usuários filtrados no formato de dicionários.
        """
        filtered_users = self._user_df.copy()
        if filtered_users.empty:
            self.logger.warn("Lista de usuários vazia")
            return filtered_users
        try:
            for key, value in filters.items():
                if key == "score_max":
                    filtered_users = filtered_users[filtered_users["score"] <= value]
                elif key == "score_min":
                    filtered_users = filtered_users[filtered_users["score"] >= value]
                else:
                    filtered_users = filtered_users[filtered_users[key] == value]
            return filtered_users
        except Exception as e:
            self.logger.error("Problema em aplicar filtros", exc_info=e)
            return pd.DataFrame()

    def _dftojson(self, df):
        return df.to_dict(orient="records")